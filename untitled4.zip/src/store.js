let store = {
    buttons: [
        {val: '1'}, {val: '2'}, {val: '3'}, {val: '4'}, {val: '5'}, {val: '6'},
        {val: '7'}, {val: '8'}, {val: '9'}, {val: '0'}, {val: '+'}, {val: '-'},
        {val: '*'}, {val: '/'}

    ],
    operations: [
        {val: 'CE'}, {val: 'C'}, {val: '='}
    ]
}
export default store