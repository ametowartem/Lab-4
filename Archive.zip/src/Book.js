import React from 'react';

function Book({ title, author, size = 100, imageUrl, price }) {

  return (
    <div>
      <img src={imageUrl} alt={title}  width={size} />
      <h6>{title}</h6>
      <p>Автор: {author}</p>
      <p>Цена: {price} ₽</p>
    </div>
  );
}

export default Book;
