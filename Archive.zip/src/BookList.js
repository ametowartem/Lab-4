import React from 'react';
import Book from './Book';

function Card({children}) {
    return (<div className="row">{children}</div>);

}

function BookList({ books }) {
  return (
    <div className="container-fluid" >
      <Card>
        {books.map((book, index) => (
          <div key={index} className="col-md-2">
            <Book {...book} />
          </div>
        ))}
     </Card>
    </div>
  );
}

export default BookList;
