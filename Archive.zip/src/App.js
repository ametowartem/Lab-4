import Navbar from './Navbar';
import BookList from './BookList';



function App() {

  const top_books = [
    {
      title: 'Всё закончится, а ты нет. Книга силы, утешения и поддержки',
      author: 'Ольга Примаченко',
      imageUrl: 'https://bombora.ru/upload/adwex.minified/webp/eaf/80/eaf8148dfecd139b9bf360dd83f27b3c.webp',
      price: 835,
      size: 200,
    },
    {
      title: 'Женщина, у которой есть план. Правила счастливой жизни',
      author: 'Мэй Маск',
      imageUrl: 'https://bombora.ru/upload/adwex.minified/webp/ec9/80/ec9ac048792e61ad2daa9c3bcab35433.webp',
      price: 786,
      size: 200,

    },
    {
      title: 'НИ СЫ. Будь уверен в своих силах и не позволяй сомнениям мешать тебе двигаться вперед',
      imageUrl: 'https://bombora.ru/upload/adwex.minified/webp/709/80/7098b8cf215869c91bbd2cc97248d014.webp',
      author: 'Джен Синсеро',
      price: 726,
      size: 200,

    },
    {
      title: 'НИ СЫ. Будь уверен в своих силах и не позволяй сомнениям мешать тебе двигаться вперед',
      imageUrl: 'https://bombora.ru/upload/adwex.minified/webp/709/80/7098b8cf215869c91bbd2cc97248d014.webp',
      author: 'Джен Синсеро',
      price: 726,
      size: 200,

    },
    {
      title: 'НИ СЫ. Будь уверен в своих силах и не позволяй сомнениям мешать тебе двигаться вперед',
      imageUrl: 'https://bombora.ru/upload/adwex.minified/webp/709/80/7098b8cf215869c91bbd2cc97248d014.webp',
      author: 'Джен Синсеро',
      price: 726,
      size: 200,

    },
    {
      title: 'НИ СЫ. Будь уверен в своих силах и не позволяй сомнениям мешать тебе двигаться вперед',
      imageUrl: 'https://bombora.ru/upload/adwex.minified/webp/709/80/7098b8cf215869c91bbd2cc97248d014.webp',
      author: 'Джен Синсеро',
      price: 726,
      size: 200,

    },
  ];

  const new_books = [
    {
      title: 'Одно лечит, другое калечит. Польза и риски при приеме лекарств, о которых не расскажут в аптеке',
      author: 'Екатерина Елисеева',
      imageUrl: 'https://bombora.ru/upload/adwex.minified/webp/ea6/80/ea65853a9886e19f6a4698ff2953b8e6.webp',
      price: 773,
    },
    {
      title: 'Metropolis. Город как величайшее достижение цивилизации',
      author: 'Бен Уилсон',
      imageUrl: 'https://bombora.ru/upload/adwex.minified/webp/e6d/80/e6d84c3267b6b9185279e7b94057a04d.webp',
      price: 240,
    },
    {
      title: 'Неидеальная медицина. Кто виноват, когда в больнице что-то идет не так, и как пациенту при этом не пострадать',
      author: 'Даниэль Офри',
      imageUrl: 'https://bombora.ru/upload/adwex.minified/webp/bab/80/bab1a4b5fc08cf43c41686422a4898e2.webp',
      price: 118,
    },
    {
      title: 'Неидеальная медицина. Кто виноват, когда в больнице что-то идет не так, и как пациенту при этом не пострадать',
      author: 'Даниэль Офри',
      imageUrl: 'https://bombora.ru/upload/adwex.minified/webp/bab/80/bab1a4b5fc08cf43c41686422a4898e2.webp',
      price: 118,
    },
    {
      title: 'Неидеальная медицина. Кто виноват, когда в больнице что-то идет не так, и как пациенту при этом не пострадать',
      author: 'Даниэль Офри',
      imageUrl: 'https://bombora.ru/upload/adwex.minified/webp/bab/80/bab1a4b5fc08cf43c41686422a4898e2.webp',
      price: 118,
    },
    {
      title: 'Неидеальная медицина. Кто виноват, когда в больнице что-то идет не так, и как пациенту при этом не пострадать',
      author: 'Даниэль Офри',
      imageUrl: 'https://bombora.ru/upload/adwex.minified/webp/bab/80/bab1a4b5fc08cf43c41686422a4898e2.webp',
      price: 118,
    },
  ]





  return (
    <div className="App">
      <Navbar />
      <div className="container">
        <h1>Добро пожайловать в магазин Anpilov Books</h1>
        <br></br>
        <div>
          <h2>Топ книг месяца</h2>
          <BookList books={top_books} />
        </div>

        <div>
          <h2>Новинки</h2>
          <BookList books={new_books} />
        </div>
      </div>
    </div>
  );
}

export default App;
