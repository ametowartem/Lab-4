import Book from "./components/Book";
import {Search} from "@mui/icons-material";
import * as PropTypes from "prop-types";
import {AppBar, Box, Button, IconButton, InputBase, Toolbar, Typography} from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import { styled, alpha} from '@mui/material/styles';
import TopBook from "./components/TopBook";

function SearchIconWrapper(props) {
	return null;
}

SearchIconWrapper.propTypes = {children: PropTypes.node};

function App() {
	const pages = ['Акции', 'Распродажа', 'Подборки', 'Читай-журнал'];
	const BooksList =[{
		image: 'https://cdn.img-gorod.ru/400x560/nomenclature/30/041/3004193-3.jpg',
		name: 'Колесо Времени. Книга 11. Нож сновидений',
		price: '977 ₽',
		author: 'Роберт Джордан'
	},{
		image: 'https://cdn.img-gorod.ru/400x560/nomenclature/30/003/3000346-7.jpg',
		name: 'Пробуждение тьмы',
		price: '481 ₽',
		author: 'Риган Хэйс'
	},{
		image: 'https://cdn.img-gorod.ru/400x560/nomenclature/30/012/3001263-4.jpg',
		name: 'Дело Аляски Сандерс',
		price: '830 ₽',
		author: 'Жоэль Диккер'
	},{
		image: 'https://cdn.img-gorod.ru/400x560/nomenclature/30/003/3000369-9.jpg',
		name: 'Сияние полуночи',
		price: '443 ₽',
		author: 'Алиса Жданова'
	},]
	const TopBooksList =[{
		image: 'https://cdn.img-gorod.ru/400x560/nomenclature/30/012/3001250-6.jpg',
		name: 'Колесо Времени. Книга 11. Нож сновидений',
		price: '977 ₽',
		author: 'Роберт Джордан'
	},{
		image: 'https://cdn.img-gorod.ru/400x560/nomenclature/30/003/3000346-7.jpg',
		name: 'Пробуждение тьмы',
		price: '481 ₽',
		author: 'Риган Хэйс'
	},{
		image: 'https://cdn.img-gorod.ru/400x560/nomenclature/30/012/3001263-4.jpg',
		name: 'Дело Аляски Сандерс',
		price: '830 ₽',
		author: 'Жоэль Диккер'
	},{
		image: 'https://cdn.img-gorod.ru/400x560/nomenclature/30/003/3000369-9.jpg',
		name: 'Сияние полуночи',
		price: '443 ₽',
		author: 'Алиса Жданова'
	},]
	const Search = styled('div')(({ theme }) => ({
  position: 'relative',
  borderRadius: theme.shape.borderRadius,
  backgroundColor: alpha(theme.palette.common.white, 0.15),
  '&:hover': {
    backgroundColor: alpha(theme.palette.common.white, 0.25),
  },
  marginLeft: 0,
  width: '100%',
  [theme.breakpoints.up('sm')]: {
    marginLeft: theme.spacing(1),
    width: 'auto',
  },
}));

const SearchIconWrapper = styled('div')(({ theme }) => ({
  padding: theme.spacing(0, 2),
  height: '100%',
  position: 'absolute',
  pointerEvents: 'none',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
}));

const StyledInputBase = styled(InputBase)(({ theme }) => ({
  color: 'inherit',
  '& .MuiInputBase-input': {
    padding: theme.spacing(1, 1, 1, 0),
    // vertical padding + font size from searchIcon
    paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('sm')]: {
      width: '12ch',
      '&:focus': {
        width: '20ch',
      },
    },
  },
}));
  return (
		<>
			<AppBar position="static">
        <Toolbar>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="open drawer"
            sx={{ mr: 2 }}
          >
            <MenuIcon />
          </IconButton>
          <Typography
            variant="h6"
            noWrap
            component="div"
            sx={{ flexGrow: 1, display: { xs: 'none', sm: 'block' } }}
          >
            Читай город
          </Typography>
	        <Box sx={{ flexGrow: 1, display: { xs: 'none', md: 'flex' } }}>
            {pages.map((page) => (
              <Button
                key={page}
                sx={{ my: 2,mr: 4, color: 'white', display: 'block' }}
              >
                {page}
              </Button>
            ))}
          </Box>
          <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search…"
              inputProps={{ 'aria-label': 'search' }}
            />
          </Search>
        </Toolbar>
      </AppBar>
			<center><h1>Лучшие из Лучших</h1></center>
    <div style={{display:"flex", marginLeft: 250}}>
	    {TopBooksList.map((item)=>
	    <TopBook {...item}
		    />
	    )}
	    </div>
			<center><h1>Ассортимент</h1></center>
    <div style={{display:"flex", marginLeft: 250}}>
	    {BooksList.map((item)=>
	    <Book
		    {...item}
		    />
	    )}
    </div>
			</>
  );
}

export default App;
