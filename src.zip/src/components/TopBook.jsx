import React from 'react';
import {Button, CardActions, CardContent, Typography} from "@mui/material";

function TopBook({image = 'https://cdn.img-gorod.ru/400x560/nomenclature/30/067/3006760-4.jpg',name,price,author}) {
	return (
		<div>
			<CardContent sx={{width: 200, height: 300}}>
      <img src={image} style={{width: 100, height: 150, marginLeft: 50}}/>
				<br></br><br></br>
				<Typography sx={{ mb: 1.5, fontSize: 25, ml: 8}}>
	      {price}
      </Typography>
      <Typography sx={{ mb: 1.5}}>
	      {name}
      </Typography>
				<Typography sx={{ mb: 1.5 }} color="text.secondary">
	      {author}
      </Typography>
    </CardContent>
    <CardActions>
      <Button size="medium" variant="contained" sx={{ml: 2, width: 170}}>Купить</Button>
    </CardActions>
		</div>
	);
};

export default TopBook;