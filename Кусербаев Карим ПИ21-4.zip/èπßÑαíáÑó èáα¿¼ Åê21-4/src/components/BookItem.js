import React from 'react';
function Cover({image, title, size}) {
    return (
        <img     src={image}
                 className="card-img-top"
                 alt={title}
                 width = {size}
                 height = {size*5.5}
    />)
};
const BookItem = ({ book }) => {
    return (
        <div className="col-md-4">
            <div className="card">
                <Cover image={book.image} title={book.title} size={100} />
                <div className="card-body">
                    <h5 className="card-title">{book.title}</h5>
                    <p className="card-text">{book.author}</p>
                    <p className="card-text">${book.price}</p>
                </div>
            </div>
        </div>
    );
};

export default BookItem;
