import React from 'react';

const BookDetail = ({ book }) => {
    return (
        <div className="container">
            <div className="row">
                <div className="col-md-4">
                    <img src={book.image} alt={book.title} />
                </div>
                <div className="col-md-8">
                    <h1>{book.title}</h1>
                    <p>{book.author}</p>
                    <p>${book.price}</p>
                    <button className="btn btn-primary">Add to Cart</button>
                </div>
            </div>
        </div>
    );
};

export default BookDetail;
